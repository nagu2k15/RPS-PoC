using System;
using Xunit;
namespace RPSXUnitTestProject
{
    public class UnitTest1
    {

        
         
        [Fact]
        public void ShouldReturnPlayer1AsWinner()
        {
            var player1 = new PlayerHumanPlayer("Human name", new Scissors());
            var player2 = new PlayerComputerRandom("Computer", new Rock());

            string result = findWinner(player1, player2);

            Assert.Equal("Computer", result);
        }

        private string findWinner(PlayerHumanPlayer player1, PlayerComputerRandom player2)
        {
            throw new NotImplementedException();
        }
    }

    internal class Rock
    {
        public Rock()
        {
        }
    }

    internal class PlayerComputerRandom
    {
        private string v;
        private Rock rock;

        public PlayerComputerRandom(string v, Rock rock)
        {
            this.v = v;
            this.rock = rock;
        }
    }

    internal class PlayerHumanPlayer
    {
        private string v;
        private Scissors scissors;

        public PlayerHumanPlayer(string v, Scissors scissors)
        {
            this.v = v;
            this.scissors = scissors;
        }
    }

    internal class Scissors
    {
    }

    public class Rps
    {
    }
}
