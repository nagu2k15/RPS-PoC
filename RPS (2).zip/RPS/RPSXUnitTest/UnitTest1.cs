using System;
using Xunit;
using RPSXUnitTest;

namespace RPSXUnitTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
