﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RPS;
using RockPaperScissors;
namespace RPSTestProject

{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ShouldReturnPlayer1AsWinner()
        {
            var player1 = new 
            var player2 = new Round();

            string result = Round.Equals(player1, player2);

            Assert.AreEqual(result, "Computer");
        }

    }
}
